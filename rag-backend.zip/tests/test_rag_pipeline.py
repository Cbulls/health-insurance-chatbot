"""Pipeline tests with in-memory fakes — no real OpenAI/Qdrant needed.

These verify the two branches that matter most: a grounded answer with sources,
and the fallback (search-substitution) path when retrieval is too weak.
"""
from __future__ import annotations

from collections.abc import AsyncIterator

import pytest

from app.core.prompt_builder import PromptBuilder
from app.core.query_router import QueryRouter
from app.core.rag_pipeline import RAGPipeline
from app.services.embedding.base import EmbeddingClient
from app.services.llm.base import LLMClient
from app.services.vectorstore.base import SearchFilter, SearchHit, VectorStore


class FakeEmbedding(EmbeddingClient):
    @property
    def dimension(self) -> int:
        return 3

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[0.1, 0.2, 0.3] for _ in texts]


class FakeLLM(LLMClient):
    def __init__(self) -> None:
        self.last_system_prompt: str | None = None

    async def generate(self, system_prompt: str, user_prompt: str) -> str:
        self.last_system_prompt = system_prompt
        return "생성된 답변"

    async def generate_stream(
        self, system_prompt: str, user_prompt: str
    ) -> AsyncIterator[str]:
        yield "생성된 "
        yield "답변"


class FakeVectorStore(VectorStore):
    def __init__(self, hits: list[SearchHit]) -> None:
        self._hits = hits

    async def ensure_collection(self, dimension: int) -> None:
        return None

    async def upsert(self, chunks) -> None:
        return None

    async def search(self, query_vector, top_k, filters: SearchFilter | None = None):
        return self._hits[:top_k]

    async def delete_by_document(self, document_id: str) -> None:
        return None


def _make_pipeline(hits: list[SearchHit], llm: FakeLLM, threshold: float = 0.35):
    return RAGPipeline(
        embedding=FakeEmbedding(),
        vector_store=FakeVectorStore(hits),
        llm=llm,
        query_router=QueryRouter(score_threshold=threshold),
        prompt_builder=PromptBuilder(),
        top_k=5,
    )


@pytest.mark.asyncio
async def test_answer_with_strong_hit_returns_sources():
    hits = [
        SearchHit(
            chunk_id="c1",
            document_id="d1",
            text="예금 신규 가입 절차는 ...",
            parent_id=None,
            score=0.82,
            source="예금업무매뉴얼 v3",
        )
    ]
    llm = FakeLLM()
    pipeline = _make_pipeline(hits, llm)

    answer = await pipeline.answer("예금 신규 가입 어떻게 하나요?")

    assert answer.is_fallback is False
    assert answer.text == "생성된 답변"
    assert len(answer.sources) == 1
    assert answer.sources[0].document_id == "d1"
    # strong hit -> normal (non-fallback) system prompt used
    assert "근거 자료" in llm.last_system_prompt or "규칙" in llm.last_system_prompt


@pytest.mark.asyncio
async def test_answer_with_weak_hit_triggers_fallback():
    hits = [
        SearchHit(
            chunk_id="c1",
            document_id="d1",
            text="관련성 낮은 내용",
            parent_id=None,
            score=0.10,  # below threshold
            source="기타문서",
        )
    ]
    llm = FakeLLM()
    pipeline = _make_pipeline(hits, llm)

    answer = await pipeline.answer("전혀 관련 없는 질문")

    assert answer.is_fallback is True
    # fallback path must not present authoritative sources
    assert answer.sources == []


@pytest.mark.asyncio
async def test_no_hits_triggers_fallback():
    llm = FakeLLM()
    pipeline = _make_pipeline([], llm)

    answer = await pipeline.answer("자료가 없는 질문")

    assert answer.is_fallback is True
    assert answer.sources == []


@pytest.mark.asyncio
async def test_stream_yields_tokens():
    hits = [
        SearchHit(
            chunk_id="c1", document_id="d1", text="내용", parent_id=None,
            score=0.9, source="문서",
        )
    ]
    pipeline = _make_pipeline(hits, FakeLLM())

    tokens = [t async for t in pipeline.answer_stream("질문")]

    assert "".join(tokens) == "생성된 답변"
