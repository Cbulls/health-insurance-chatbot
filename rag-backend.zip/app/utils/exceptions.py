"""Domain-specific exceptions.

Keeping a small exception hierarchy lets the API layer translate failures into
the right HTTP status codes without leaking library-specific errors (OpenAI,
Qdrant) up the stack.
"""
from __future__ import annotations


class RAGError(Exception):
    """Base class for all application errors."""


class DocumentNotFoundError(RAGError):
    """Raised when a requested document does not exist."""


class IngestionError(RAGError):
    """Raised when a document fails to be parsed, embedded or stored."""


class LLMError(RAGError):
    """Raised when the LLM provider call fails."""


class EmbeddingError(RAGError):
    """Raised when the embedding provider call fails."""


class VectorStoreError(RAGError):
    """Raised when the vector store operation fails."""


class UnsupportedFileTypeError(IngestionError):
    """Raised when an uploaded document type cannot be parsed."""
