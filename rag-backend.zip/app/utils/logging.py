"""Logging configuration.

A single ``configure_logging`` call wires up the root logger. We keep it simple
(stdlib logging) but structured enough that log lines are greppable in any log
aggregator. Call this once at application startup.
"""
from __future__ import annotations

import logging
import sys


def configure_logging(level: str = "INFO") -> None:
    """Configure the root logger. Idempotent."""
    root = logging.getLogger()
    if root.handlers:
        # Already configured (e.g. reload); just adjust the level.
        root.setLevel(level.upper())
        return

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    )
    root.addHandler(handler)
    root.setLevel(level.upper())

    # OpenAI / httpx are very chatty at DEBUG; keep them at WARNING.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
