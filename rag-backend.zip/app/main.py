"""FastAPI application entry point.

Wires the container into ``app.state`` on startup (lifespan), registers routers,
CORS and a uniform exception handler that maps domain errors to HTTP codes.
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.deps import build_container
from app.api.routes import chat, documents, health
from app.config import get_settings
from app.utils.exceptions import (
    DocumentNotFoundError,
    EmbeddingError,
    LLMError,
    RAGError,
    VectorStoreError,
)
from app.utils.logging import configure_logging, get_logger

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    configure_logging(settings.log_level)
    logger.info("Starting %s (%s)", settings.app_name, settings.environment)

    container = build_container()
    await container.startup()
    app.state.container = container

    yield

    logger.info("Shutting down")


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title=settings.app_name, lifespan=lifespan)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # tighten in production
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(health.router)
    app.include_router(chat.router)
    app.include_router(documents.router)

    _register_exception_handlers(app)
    return app


def _register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(DocumentNotFoundError)
    async def _not_found(_: Request, exc: DocumentNotFoundError):
        return JSONResponse(status_code=404, content={"detail": "Document not found"})

    @app.exception_handler((LLMError, EmbeddingError, VectorStoreError))
    async def _upstream(_: Request, exc: RAGError):
        # Failures in external providers are surfaced as 502 Bad Gateway.
        logger.error("Upstream dependency error: %s", exc)
        return JSONResponse(status_code=502, content={"detail": "Upstream service error"})

    @app.exception_handler(RAGError)
    async def _generic(_: Request, exc: RAGError):
        logger.error("Application error: %s", exc)
        return JSONResponse(status_code=400, content={"detail": str(exc)})


app = create_app()
