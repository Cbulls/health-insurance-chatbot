"""Application configuration.

All tunables live here and are sourced from environment variables (or a local
``.env`` file) so that nothing vendor- or environment-specific is hard-coded in
the business logic. This is the single place that knows about concrete values
like model names, API keys and the vector store location.
"""
from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- App ---
    app_name: str = "rag-backend"
    environment: str = Field(default="dev")
    log_level: str = Field(default="INFO")

    # --- OpenAI ---
    openai_api_key: str = Field(default="", description="OpenAI API key")
    llm_model: str = Field(default="gpt-4o-mini")
    embedding_model: str = Field(default="text-embedding-3-small")
    # Dimension of the embedding model above; text-embedding-3-small = 1536.
    embedding_dim: int = Field(default=1536)
    llm_temperature: float = Field(default=0.0)
    llm_request_timeout: float = Field(default=60.0)

    # --- Qdrant ---
    qdrant_url: str = Field(default="http://localhost:6333")
    qdrant_api_key: str | None = Field(default=None)
    qdrant_collection: str = Field(default="knowledge_base")

    # --- Retrieval / chunking ---
    chunk_size: int = Field(default=800, description="Target chunk size in characters")
    chunk_overlap: int = Field(default=120)
    retrieval_top_k: int = Field(default=5)
    # Minimum similarity score (0..1). Below this the pipeline triggers fallback.
    score_threshold: float = Field(default=0.35)


@lru_cache
def get_settings() -> Settings:
    """Return a cached singleton ``Settings`` instance."""
    return Settings()
