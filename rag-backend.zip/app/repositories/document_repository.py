"""Document metadata repository.

Stores the catalogue of registered documents (titles, types, versions) separately
from the vector store, which only holds chunk vectors. This in-memory
implementation is fine for a first cut and tests; swapping to Postgres later
means reimplementing this same small interface.
"""
from __future__ import annotations

from app.models.document import Document
from app.utils.exceptions import DocumentNotFoundError


class DocumentRepository:
    """In-memory document catalogue. Not safe across processes; replace with a
    real database (e.g. SQLAlchemy + Postgres) for production."""

    def __init__(self) -> None:
        self._store: dict[str, Document] = {}

    async def add(self, document: Document) -> Document:
        self._store[document.id] = document
        return document

    async def get(self, document_id: str) -> Document:
        doc = self._store.get(document_id)
        if doc is None:
            raise DocumentNotFoundError(document_id)
        return doc

    async def list(
        self,
        doc_type: str | None = None,
        business_area: str | None = None,
    ) -> list[Document]:
        items = list(self._store.values())
        if doc_type:
            items = [d for d in items if d.metadata.doc_type.value == doc_type]
        if business_area:
            items = [d for d in items if d.metadata.business_area == business_area]
        return sorted(items, key=lambda d: d.created_at, reverse=True)

    async def delete(self, document_id: str) -> None:
        if document_id not in self._store:
            raise DocumentNotFoundError(document_id)
        del self._store[document_id]
