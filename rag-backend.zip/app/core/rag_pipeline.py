"""RAG orchestration — the heart of the system.

``answer`` implements exactly the flow drawn in the proposal:
    question -> intent analysis -> embed -> search -> (fallback?) -> generate
        -> answer with sources.

It composes the injected services but contains the decision logic itself.
"""
from __future__ import annotations

from collections.abc import AsyncIterator

from app.core.prompt_builder import PromptBuilder
from app.core.query_router import QueryRouter
from app.models.chat import (
    Answer,
    AnswerSource,
    RetrievedContext,
)
from app.services.embedding.base import EmbeddingClient
from app.services.llm.base import LLMClient
from app.services.vectorstore.base import SearchFilter, SearchHit, VectorStore
from app.utils.logging import get_logger

logger = get_logger(__name__)


class RAGPipeline:
    def __init__(
        self,
        embedding: EmbeddingClient,
        vector_store: VectorStore,
        llm: LLMClient,
        query_router: QueryRouter,
        prompt_builder: PromptBuilder,
        top_k: int,
    ) -> None:
        self._embedding = embedding
        self._vector_store = vector_store
        self._llm = llm
        self._router = query_router
        self._prompts = prompt_builder
        self._top_k = top_k

    async def _retrieve(self, query: str) -> list[SearchHit]:
        query_vector = await self._embedding.embed_one(query)
        return await self._vector_store.search(
            query_vector=query_vector,
            top_k=self._top_k,
            filters=SearchFilter(active_only=True),
        )

    @staticmethod
    def _to_contexts(hits: list[SearchHit]) -> list[RetrievedContext]:
        return [
            RetrievedContext(
                chunk_id=h.chunk_id,
                document_id=h.document_id,
                text=h.text,
                source=h.source,
                score=h.score,
            )
            for h in hits
        ]

    @staticmethod
    def _to_sources(hits: list[SearchHit]) -> list[AnswerSource]:
        # De-duplicate by document, keeping the highest score per document.
        best: dict[str, AnswerSource] = {}
        for h in hits:
            existing = best.get(h.document_id)
            if existing is None or h.score > existing.score:
                best[h.document_id] = AnswerSource(
                    document_id=h.document_id, source=h.source, score=h.score
                )
        return sorted(best.values(), key=lambda s: s.score, reverse=True)

    async def answer(self, query: str) -> Answer:
        intent = self._router.analyze_intent(query)
        hits = await self._retrieve(query)
        is_fallback = self._router.should_fallback(hits)

        contexts = self._to_contexts(hits)
        system_prompt = self._prompts.build_system_prompt(is_fallback)
        user_prompt = self._prompts.build_user_prompt(query, contexts, intent)

        text = await self._llm.generate(system_prompt, user_prompt)

        # On fallback we still surface the weak hits as "관련 자료" pointers, but
        # we do not present them as authoritative sources.
        sources = [] if is_fallback else self._to_sources(hits)

        logger.info(
            "answer: intent=%s fallback=%s hits=%d",
            intent.type.value,
            is_fallback,
            len(hits),
        )
        return Answer(
            text=text,
            sources=sources,
            is_fallback=is_fallback,
            intent=intent.type,
        )

    async def answer_stream(self, query: str) -> AsyncIterator[str]:
        """Stream the answer text token-by-token (sources omitted in stream)."""
        intent = self._router.analyze_intent(query)
        hits = await self._retrieve(query)
        is_fallback = self._router.should_fallback(hits)
        contexts = self._to_contexts(hits)
        system_prompt = self._prompts.build_system_prompt(is_fallback)
        user_prompt = self._prompts.build_user_prompt(query, contexts, intent)
        async for token in self._llm.generate_stream(system_prompt, user_prompt):
            yield token
