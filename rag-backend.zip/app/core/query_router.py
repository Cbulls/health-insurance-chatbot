"""Query routing — intent analysis and the fallback decision.

This is the code form of the proposal's chatbot-UX branch point: classify the
query, then decide whether retrieval was good enough to answer or whether we
must fall back to search-substitution.

Intent classification here is a fast, deterministic heuristic. It can be
upgraded to an LLM classifier behind this same interface without touching the
pipeline.
"""
from __future__ import annotations

from app.models.chat import Intent, IntentType
from app.services.vectorstore.base import SearchHit

# Korean + English cue words per intent. Cheap but surprisingly effective for
# routing; the LLM still does the heavy lifting on the actual answer.
_HOW_CUES = ("어떻게", "방법", "절차", "how")
_WHERE_CUES = ("어디", "위치", "where", "메뉴")
_WHAT_CUES = ("무엇", "뭐", "정의", "what", "의미")
_FAQ_CUES = ("자주", "faq", "문의")


class QueryRouter:
    def __init__(self, score_threshold: float) -> None:
        self._score_threshold = score_threshold

    def analyze_intent(self, query: str) -> Intent:
        q = query.lower()
        if any(c in q for c in _HOW_CUES):
            return Intent(type=IntentType.HOW)
        if any(c in q for c in _WHERE_CUES):
            return Intent(type=IntentType.WHERE)
        if any(c in q for c in _WHAT_CUES):
            return Intent(type=IntentType.WHAT)
        if any(c in q for c in _FAQ_CUES):
            return Intent(type=IntentType.FAQ)
        return Intent(type=IntentType.OTHER)

    def should_fallback(self, hits: list[SearchHit]) -> bool:
        """Return True when retrieval is too weak to ground an answer.

        Trigger fallback if there are no hits at all, or if even the best hit is
        below the configured similarity threshold.
        """
        if not hits:
            return True
        best = max(h.score for h in hits)
        return best < self._score_threshold
