"""Prompt construction — the code form of the proposal's "Instruction Set".

The system prompt encodes the non-negotiable behavioural rules (answer only from
the provided evidence, always cite sources, refuse to fabricate). The user
prompt injects the retrieved context. Centralising this here keeps prompting
consistent across every query and makes the rules auditable in one place.
"""
from __future__ import annotations

from app.models.chat import Intent, RetrievedContext

_SYSTEM_PROMPT = """\
당신은 저축은행중앙회의 업무 매뉴얼·제도/규정 안내를 돕는 도우미입니다.
다음 규칙을 반드시 지키십시오.

1. 제공된 [근거 자료]에 있는 내용만으로 답변하십시오.
2. 근거에 없는 내용은 추측하지 말고 "제공된 자료에서 확인되지 않습니다"라고 답하십시오.
3. 답변 끝에 사용한 근거의 출처를 명시하십시오.
4. 규정 해석은 원문에 근거하여 정확히 전달하고, 임의로 일반화하지 마십시오.
5. 개인정보나 비공개 정보로 보이는 내용은 답변에 포함하지 마십시오.

답변 형식:
- 핵심 답변을 먼저 제시한 뒤, 필요한 경우 상세 설명을 단계적으로 덧붙이십시오.
"""

_FALLBACK_SYSTEM_PROMPT = """\
당신은 저축은행중앙회의 업무 안내 도우미입니다.
사용자의 질문에 대해 충분히 일치하는 근거 자료를 찾지 못했습니다.
정확한 답변을 지어내지 말고, 다음을 수행하십시오.

1. 정확한 답을 찾지 못했음을 사용자에게 분명히 알리십시오.
2. 제공된 [참고 자료]가 있다면 관련성이 있을 수 있는 항목으로 안내하십시오.
3. 필요 시 담당 부서 문의 또는 검색어 재구성을 정중히 제안하십시오.
"""


class PromptBuilder:
    def build_system_prompt(self, is_fallback: bool) -> str:
        return _FALLBACK_SYSTEM_PROMPT if is_fallback else _SYSTEM_PROMPT

    def build_user_prompt(
        self,
        query: str,
        contexts: list[RetrievedContext],
        intent: Intent,
    ) -> str:
        if contexts:
            evidence_blocks = []
            for i, ctx in enumerate(contexts, start=1):
                evidence_blocks.append(
                    f"[{i}] (출처: {ctx.source})\n{ctx.text}"
                )
            evidence = "\n\n".join(evidence_blocks)
            label = "근거 자료"
        else:
            evidence = "(관련 자료 없음)"
            label = "참고 자료"

        return (
            f"[{label}]\n{evidence}\n\n"
            f"[사용자 질문]\n{query}\n\n"
            f"위 자료에 근거하여 답변하십시오."
        )
