"""Ingestion pipeline (AIC-002 ①②): the INPUT -> ENGINE -> OUTPUT flow.

Parses a document, chunks it, embeds the chunks, writes vectors to the vector
store and registers the document in the catalogue. Dependencies are injected so
the pipeline knows nothing about OpenAI or Qdrant specifically.
"""
from __future__ import annotations

from app.models.document import Document, DocumentMetadata
from app.repositories.document_repository import DocumentRepository
from app.services.embedding.base import EmbeddingClient
from app.services.parser import document_parser
from app.services.vectorstore.base import VectorStore
from app.utils.exceptions import IngestionError
from app.utils.logging import get_logger

logger = get_logger(__name__)


class IngestionPipeline:
    def __init__(
        self,
        embedding: EmbeddingClient,
        vector_store: VectorStore,
        repository: DocumentRepository,
        chunk_size: int,
        chunk_overlap: int,
    ) -> None:
        self._embedding = embedding
        self._vector_store = vector_store
        self._repository = repository
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap

    async def ingest(
        self,
        *,
        filename: str,
        raw: bytes,
        title: str,
        metadata: DocumentMetadata,
    ) -> Document:
        # 1. Parse
        text = document_parser.parse(filename, raw)
        if not text.strip():
            raise IngestionError(f"No extractable text in {filename}")

        # 2. Register the document so chunks can reference its id
        document = Document(title=title, source=filename, metadata=metadata)

        # 3. Chunk
        chunks = document_parser.build_chunks(
            document_id=document.id,
            text=text,
            metadata=metadata,
            size=self._chunk_size,
            overlap=self._chunk_overlap,
        )
        if not chunks:
            raise IngestionError(f"Document produced no chunks: {filename}")

        # 4. Embed (batch)
        vectors = await self._embedding.embed([c.text for c in chunks])
        for chunk, vector in zip(chunks, vectors):
            chunk.embedding = vector

        # 5. Persist: vectors to the store, metadata to the catalogue
        await self._vector_store.upsert(chunks)
        document.chunk_count = len(chunks)
        await self._repository.add(document)

        logger.info(
            "Ingested document %s (%s) -> %d chunks",
            document.id,
            filename,
            len(chunks),
        )
        return document

    async def remove(self, document_id: str) -> None:
        """Delete a document and all its vectors."""
        await self._repository.get(document_id)  # raises if missing
        await self._vector_store.delete_by_document(document_id)
        await self._repository.delete(document_id)
        logger.info("Removed document %s", document_id)
