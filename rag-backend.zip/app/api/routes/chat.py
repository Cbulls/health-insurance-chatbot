"""Chat endpoint. Thin HTTP layer over ``RAGPipeline``."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from app.api.deps import get_rag_pipeline
from app.api.schemas.chat import ChatRequest, ChatResponse
from app.core.rag_pipeline import RAGPipeline

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
async def chat(
    payload: ChatRequest,
    pipeline: RAGPipeline = Depends(get_rag_pipeline),
) -> ChatResponse:
    answer = await pipeline.answer(payload.query)
    return ChatResponse(
        answer=answer.text,
        sources=answer.sources,
        is_fallback=answer.is_fallback,
        intent=answer.intent,
    )


@router.post("/stream")
async def chat_stream(
    payload: ChatRequest,
    pipeline: RAGPipeline = Depends(get_rag_pipeline),
) -> StreamingResponse:
    async def event_generator():
        async for token in pipeline.answer_stream(payload.query):
            yield token

    return StreamingResponse(event_generator(), media_type="text/plain")
