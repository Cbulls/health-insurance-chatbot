"""Document management endpoints: upload/ingest, list (type-filtered), delete."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile, status

from app.api.deps import get_ingestion_pipeline, get_repository
from app.api.schemas.document import DocumentListResponse, DocumentResponse
from app.core.ingestion import IngestionPipeline
from app.models.document import Document, DocumentMetadata, DocumentType
from app.repositories.document_repository import DocumentRepository
from app.utils.exceptions import (
    DocumentNotFoundError,
    IngestionError,
    UnsupportedFileTypeError,
)

router = APIRouter(prefix="/documents", tags=["documents"])


def _to_response(doc: Document) -> DocumentResponse:
    return DocumentResponse(
        id=doc.id,
        title=doc.title,
        source=doc.source,
        doc_type=doc.metadata.doc_type,
        business_area=doc.metadata.business_area,
        version=doc.metadata.version,
        is_active=doc.metadata.is_active,
        chunk_count=doc.chunk_count,
        created_at=doc.created_at,
    )


@router.post("", response_model=DocumentResponse, status_code=status.HTTP_201_CREATED)
async def ingest_document(
    file: UploadFile,
    title: str = Form(...),
    doc_type: DocumentType = Form(DocumentType.OTHER),
    business_area: str | None = Form(None),
    version: str | None = Form(None),
    pipeline: IngestionPipeline = Depends(get_ingestion_pipeline),
) -> DocumentResponse:
    raw = await file.read()
    metadata = DocumentMetadata(
        doc_type=doc_type,
        business_area=business_area,
        version=version,
    )
    try:
        document = await pipeline.ingest(
            filename=file.filename or "untitled",
            raw=raw,
            title=title,
            metadata=metadata,
        )
    except UnsupportedFileTypeError as exc:
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, str(exc)) from exc
    except IngestionError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc
    return _to_response(document)


@router.get("", response_model=DocumentListResponse)
async def list_documents(
    doc_type: str | None = None,
    business_area: str | None = None,
    repo: DocumentRepository = Depends(get_repository),
) -> DocumentListResponse:
    docs = await repo.list(doc_type=doc_type, business_area=business_area)
    items = [_to_response(d) for d in docs]
    return DocumentListResponse(items=items, total=len(items))


@router.delete("/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_document(
    document_id: str,
    pipeline: IngestionPipeline = Depends(get_ingestion_pipeline),
) -> None:
    try:
        await pipeline.remove(document_id)
    except DocumentNotFoundError as exc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found") from exc
