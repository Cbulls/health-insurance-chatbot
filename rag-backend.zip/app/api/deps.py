"""Composition root.

This is the ONE place that knows which concrete implementations to use. Swapping
OpenAI for another LLM, or Qdrant for another vector DB, is a change here and
nowhere else. Components are built once and cached on ``app.state`` at startup
(see main.py lifespan), and exposed to routes via FastAPI ``Depends``.
"""
from __future__ import annotations

from fastapi import Request

from app.config import Settings, get_settings
from app.core.ingestion import IngestionPipeline
from app.core.prompt_builder import PromptBuilder
from app.core.query_router import QueryRouter
from app.core.rag_pipeline import RAGPipeline
from app.repositories.document_repository import DocumentRepository
from app.services.embedding.base import EmbeddingClient
from app.services.embedding.openai_client import OpenAIEmbeddingClient
from app.services.llm.base import LLMClient
from app.services.llm.openai_client import OpenAILLMClient
from app.services.vectorstore.base import VectorStore
from app.services.vectorstore.qdrant_store import QdrantVectorStore


class Container:
    """Holds singletons for the lifetime of the application."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

        # --- services (concrete implementations chosen here) ---
        self.llm: LLMClient = OpenAILLMClient(
            api_key=settings.openai_api_key,
            model=settings.llm_model,
            temperature=settings.llm_temperature,
            timeout=settings.llm_request_timeout,
        )
        self.embedding: EmbeddingClient = OpenAIEmbeddingClient(
            api_key=settings.openai_api_key,
            model=settings.embedding_model,
            dimension=settings.embedding_dim,
            timeout=settings.llm_request_timeout,
        )
        self.vector_store: VectorStore = QdrantVectorStore(
            url=settings.qdrant_url,
            collection=settings.qdrant_collection,
            api_key=settings.qdrant_api_key,
        )
        self.repository = DocumentRepository()

        # --- core (business logic) ---
        self.query_router = QueryRouter(score_threshold=settings.score_threshold)
        self.prompt_builder = PromptBuilder()
        self.rag_pipeline = RAGPipeline(
            embedding=self.embedding,
            vector_store=self.vector_store,
            llm=self.llm,
            query_router=self.query_router,
            prompt_builder=self.prompt_builder,
            top_k=settings.retrieval_top_k,
        )
        self.ingestion_pipeline = IngestionPipeline(
            embedding=self.embedding,
            vector_store=self.vector_store,
            repository=self.repository,
            chunk_size=settings.chunk_size,
            chunk_overlap=settings.chunk_overlap,
        )

    async def startup(self) -> None:
        await self.vector_store.ensure_collection(self.embedding.dimension)


def build_container() -> Container:
    return Container(get_settings())


# --- FastAPI dependency accessors -------------------------------------------
def _container(request: Request) -> Container:
    return request.app.state.container


def get_rag_pipeline(request: Request) -> RAGPipeline:
    return _container(request).rag_pipeline


def get_ingestion_pipeline(request: Request) -> IngestionPipeline:
    return _container(request).ingestion_pipeline


def get_repository(request: Request) -> DocumentRepository:
    return _container(request).repository
