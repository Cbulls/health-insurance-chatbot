"""HTTP DTOs for the chat endpoint. Separate from domain models so the wire
contract can evolve independently of internal structures."""
from __future__ import annotations

from pydantic import BaseModel, Field

from app.models.chat import AnswerSource, IntentType


class ChatRequest(BaseModel):
    query: str = Field(min_length=1, max_length=2000)
    stream: bool = Field(default=False)


class ChatResponse(BaseModel):
    answer: str
    sources: list[AnswerSource]
    is_fallback: bool
    intent: IntentType
