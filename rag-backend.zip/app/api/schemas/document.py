"""HTTP DTOs for document endpoints."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from app.models.document import DocumentType


class DocumentResponse(BaseModel):
    id: str
    title: str
    source: str
    doc_type: DocumentType
    business_area: str | None
    version: str | None
    is_active: bool
    chunk_count: int
    created_at: datetime


class DocumentListResponse(BaseModel):
    items: list[DocumentResponse]
    total: int
