"""LLM provider abstraction.

Core logic depends on this interface, never on the OpenAI SDK directly. Swapping
providers (or dropping in a mock for tests) means writing a new implementation
of ``LLMClient`` and changing one line in the composition root (main.py).
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator


class LLMClient(ABC):
    @abstractmethod
    async def generate(self, system_prompt: str, user_prompt: str) -> str:
        """Return a single completion string."""
        raise NotImplementedError

    @abstractmethod
    def generate_stream(
        self, system_prompt: str, user_prompt: str
    ) -> AsyncIterator[str]:
        """Yield completion tokens/chunks as they arrive.

        Implementations should be ``async def`` generators. Declared without
        ``async`` here because an abstract method cannot also be a generator;
        the contract is "returns an async iterator of str".
        """
        raise NotImplementedError
