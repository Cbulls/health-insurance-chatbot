"""OpenAI implementation of ``LLMClient`` using the async SDK."""
from __future__ import annotations

from collections.abc import AsyncIterator

from openai import AsyncOpenAI, OpenAIError

from app.services.llm.base import LLMClient
from app.utils.exceptions import LLMError
from app.utils.logging import get_logger

logger = get_logger(__name__)


class OpenAILLMClient(LLMClient):
    def __init__(
        self,
        api_key: str,
        model: str,
        temperature: float = 0.0,
        timeout: float = 60.0,
    ) -> None:
        self._client = AsyncOpenAI(api_key=api_key, timeout=timeout)
        self._model = model
        self._temperature = temperature

    def _messages(self, system_prompt: str, user_prompt: str) -> list[dict]:
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    async def generate(self, system_prompt: str, user_prompt: str) -> str:
        try:
            resp = await self._client.chat.completions.create(
                model=self._model,
                temperature=self._temperature,
                messages=self._messages(system_prompt, user_prompt),
            )
        except OpenAIError as exc:  # pragma: no cover - network dependent
            logger.exception("OpenAI completion failed")
            raise LLMError(str(exc)) from exc

        content = resp.choices[0].message.content
        return content or ""

    async def generate_stream(
        self, system_prompt: str, user_prompt: str
    ) -> AsyncIterator[str]:
        try:
            stream = await self._client.chat.completions.create(
                model=self._model,
                temperature=self._temperature,
                messages=self._messages(system_prompt, user_prompt),
                stream=True,
            )
            async for event in stream:
                delta = event.choices[0].delta.content
                if delta:
                    yield delta
        except OpenAIError as exc:  # pragma: no cover - network dependent
            logger.exception("OpenAI streaming failed")
            raise LLMError(str(exc)) from exc
