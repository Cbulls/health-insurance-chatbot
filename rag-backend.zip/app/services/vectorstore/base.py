"""Vector store abstraction.

The core depends on this; the Qdrant specifics live in the implementation. A
``SearchHit`` is the minimal shape the pipeline needs back from a search.
"""
from __future__ import annotations

from abc import ABC, abstractmethod

from pydantic import BaseModel

from app.models.document import Chunk


class SearchFilter(BaseModel):
    """Optional metadata constraints applied during search."""

    business_area: str | None = None
    doc_type: str | None = None
    active_only: bool = True


class SearchHit(BaseModel):
    chunk_id: str
    document_id: str
    text: str
    parent_id: str | None
    score: float
    source: str


class VectorStore(ABC):
    @abstractmethod
    async def ensure_collection(self, dimension: int) -> None:
        """Create the collection if it does not already exist (idempotent)."""
        raise NotImplementedError

    @abstractmethod
    async def upsert(self, chunks: list[Chunk]) -> None:
        """Insert or update chunk vectors. Chunks must carry ``embedding``."""
        raise NotImplementedError

    @abstractmethod
    async def search(
        self,
        query_vector: list[float],
        top_k: int,
        filters: SearchFilter | None = None,
    ) -> list[SearchHit]:
        raise NotImplementedError

    @abstractmethod
    async def delete_by_document(self, document_id: str) -> None:
        """Remove all chunks belonging to a document."""
        raise NotImplementedError
