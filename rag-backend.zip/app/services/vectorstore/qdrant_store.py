"""Qdrant implementation of ``VectorStore`` using the async client."""
from __future__ import annotations

from qdrant_client import AsyncQdrantClient, models as qm

from app.models.document import Chunk
from app.services.vectorstore.base import SearchFilter, SearchHit, VectorStore
from app.utils.exceptions import VectorStoreError
from app.utils.logging import get_logger

logger = get_logger(__name__)


class QdrantVectorStore(VectorStore):
    def __init__(
        self,
        url: str,
        collection: str,
        api_key: str | None = None,
    ) -> None:
        self._client = AsyncQdrantClient(url=url, api_key=api_key)
        self._collection = collection

    async def ensure_collection(self, dimension: int) -> None:
        try:
            exists = await self._client.collection_exists(self._collection)
            if exists:
                return
            await self._client.create_collection(
                collection_name=self._collection,
                vectors_config=qm.VectorParams(
                    size=dimension,
                    distance=qm.Distance.COSINE,
                ),
            )
            logger.info("Created Qdrant collection '%s' (dim=%d)", self._collection, dimension)
        except Exception as exc:  # qdrant raises a variety of error types
            raise VectorStoreError(f"ensure_collection failed: {exc}") from exc

    async def upsert(self, chunks: list[Chunk]) -> None:
        if not chunks:
            return
        points: list[qm.PointStruct] = []
        for chunk in chunks:
            if chunk.embedding is None:
                raise VectorStoreError(f"Chunk {chunk.id} has no embedding")
            payload = chunk.to_payload()
            # store a display source for citation rendering
            payload["source"] = chunk.metadata.version or chunk.document_id
            points.append(
                qm.PointStruct(id=chunk.id, vector=chunk.embedding, payload=payload)
            )
        try:
            await self._client.upsert(collection_name=self._collection, points=points)
        except Exception as exc:
            raise VectorStoreError(f"upsert failed: {exc}") from exc

    def _build_filter(self, filters: SearchFilter | None) -> qm.Filter | None:
        if filters is None:
            return None
        must: list[qm.FieldCondition] = []
        if filters.active_only:
            must.append(
                qm.FieldCondition(key="is_active", match=qm.MatchValue(value=True))
            )
        if filters.business_area:
            must.append(
                qm.FieldCondition(
                    key="business_area",
                    match=qm.MatchValue(value=filters.business_area),
                )
            )
        if filters.doc_type:
            must.append(
                qm.FieldCondition(
                    key="doc_type", match=qm.MatchValue(value=filters.doc_type)
                )
            )
        return qm.Filter(must=must) if must else None

    async def search(
        self,
        query_vector: list[float],
        top_k: int,
        filters: SearchFilter | None = None,
    ) -> list[SearchHit]:
        try:
            results = await self._client.search(
                collection_name=self._collection,
                query_vector=query_vector,
                limit=top_k,
                query_filter=self._build_filter(filters),
                with_payload=True,
            )
        except Exception as exc:
            raise VectorStoreError(f"search failed: {exc}") from exc

        hits: list[SearchHit] = []
        for point in results:
            payload = point.payload or {}
            hits.append(
                SearchHit(
                    chunk_id=str(point.id),
                    document_id=payload.get("document_id", ""),
                    text=payload.get("text", ""),
                    parent_id=payload.get("parent_id"),
                    score=point.score,
                    source=payload.get("source") or payload.get("document_id", ""),
                )
            )
        return hits

    async def delete_by_document(self, document_id: str) -> None:
        try:
            await self._client.delete(
                collection_name=self._collection,
                points_selector=qm.FilterSelector(
                    filter=qm.Filter(
                        must=[
                            qm.FieldCondition(
                                key="document_id",
                                match=qm.MatchValue(value=document_id),
                            )
                        ]
                    )
                ),
            )
        except Exception as exc:
            raise VectorStoreError(f"delete failed: {exc}") from exc
