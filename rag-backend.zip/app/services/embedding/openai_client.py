"""OpenAI implementation of ``EmbeddingClient``."""
from __future__ import annotations

from openai import AsyncOpenAI, OpenAIError

from app.services.embedding.base import EmbeddingClient
from app.utils.exceptions import EmbeddingError
from app.utils.logging import get_logger

logger = get_logger(__name__)


class OpenAIEmbeddingClient(EmbeddingClient):
    def __init__(
        self,
        api_key: str,
        model: str,
        dimension: int,
        timeout: float = 60.0,
    ) -> None:
        self._client = AsyncOpenAI(api_key=api_key, timeout=timeout)
        self._model = model
        self._dimension = dimension

    @property
    def dimension(self) -> int:
        return self._dimension

    async def embed(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        try:
            resp = await self._client.embeddings.create(
                model=self._model,
                input=texts,
            )
        except OpenAIError as exc:  # pragma: no cover - network dependent
            logger.exception("OpenAI embedding failed")
            raise EmbeddingError(str(exc)) from exc

        # The SDK guarantees order, but sort by index to be safe.
        ordered = sorted(resp.data, key=lambda d: d.index)
        return [item.embedding for item in ordered]
