"""Embedding provider abstraction."""
from __future__ import annotations

from abc import ABC, abstractmethod


class EmbeddingClient(ABC):
    @property
    @abstractmethod
    def dimension(self) -> int:
        """Vector dimension produced by this embedder."""
        raise NotImplementedError

    @abstractmethod
    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts. Order of the output matches the input."""
        raise NotImplementedError

    async def embed_one(self, text: str) -> list[float]:
        """Convenience for a single text."""
        vectors = await self.embed([text])
        return vectors[0]
