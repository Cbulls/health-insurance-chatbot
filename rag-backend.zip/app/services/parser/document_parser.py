"""Document parsing and chunking.

Kept intentionally small and dependency-light: plain text / markdown are handled
directly, PDFs via pypdf. Richer parsing (OCR, tables -> markdown, the VDR
pipeline from the proposal) would slot in behind this same interface later.
"""
from __future__ import annotations

import io

from app.models.document import Chunk, DocumentMetadata
from app.utils.exceptions import UnsupportedFileTypeError
from app.utils.logging import get_logger

logger = get_logger(__name__)

_SUPPORTED_TEXT = {".txt", ".md"}


def parse(filename: str, raw: bytes) -> str:
    """Extract plain text from a supported document."""
    lower = filename.lower()
    if any(lower.endswith(ext) for ext in _SUPPORTED_TEXT):
        return raw.decode("utf-8", errors="replace")
    if lower.endswith(".pdf"):
        return _parse_pdf(raw)
    raise UnsupportedFileTypeError(f"Unsupported file type: {filename}")


def _parse_pdf(raw: bytes) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:  # pragma: no cover
        raise UnsupportedFileTypeError("pypdf not installed for PDF parsing") from exc

    reader = PdfReader(io.BytesIO(raw))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n\n".join(pages)


def chunk_text(
    text: str,
    size: int,
    overlap: int,
) -> list[str]:
    """Split text into overlapping character windows.

    A paragraph-aware splitter would be better for production, but a sliding
    window with overlap is a robust, predictable baseline that preserves local
    context across chunk boundaries.
    """
    text = text.strip()
    if not text:
        return []
    if overlap >= size:
        raise ValueError("overlap must be smaller than size")

    chunks: list[str] = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + size, n)
        piece = text[start:end].strip()
        if piece:
            chunks.append(piece)
        if end == n:
            break
        start = end - overlap
    return chunks


def build_chunks(
    document_id: str,
    text: str,
    metadata: DocumentMetadata,
    size: int,
    overlap: int,
) -> list[Chunk]:
    """Turn raw document text into a list of ``Chunk`` (without embeddings)."""
    pieces = chunk_text(text, size=size, overlap=overlap)
    return [
        Chunk(document_id=document_id, text=piece, metadata=metadata)
        for piece in pieces
    ]
