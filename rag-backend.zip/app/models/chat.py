"""Chat / RAG domain models.

``Answer`` is the heart of the contract: it always carries its ``sources`` and a
``is_fallback`` flag, which is how we realise the proposal's two key promises —
"answer with sources" and "search-substitution on exception".
"""
from __future__ import annotations

import enum

from pydantic import BaseModel, Field


class Role(str, enum.Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


class IntentType(str, enum.Enum):
    """Query intent classification (AIC-002 ③: FAQ / What / How / Where)."""

    FAQ = "faq"
    WHAT = "what"
    HOW = "how"
    WHERE = "where"
    OTHER = "other"


class Intent(BaseModel):
    type: IntentType = Field(default=IntentType.OTHER)
    # Optional structured filters derived from the query (e.g. business area).
    business_area: str | None = Field(default=None)


class Message(BaseModel):
    role: Role
    content: str


class RetrievedContext(BaseModel):
    """A single retrieval hit used as grounding evidence."""

    chunk_id: str
    document_id: str
    text: str
    source: str = Field(description="표시용 출처 (문서명/조항)")
    score: float


class AnswerSource(BaseModel):
    """A citation surfaced to the end user alongside the answer."""

    document_id: str
    source: str
    score: float


class Answer(BaseModel):
    """Final answer returned to the client."""

    text: str
    sources: list[AnswerSource] = Field(default_factory=list)
    is_fallback: bool = Field(
        default=False,
        description="검색 근거가 충분치 않아 대체 응답(검색 대체)으로 처리되었는지 여부",
    )
    intent: IntentType = Field(default=IntentType.OTHER)
