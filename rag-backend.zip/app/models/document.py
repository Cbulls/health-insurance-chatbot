"""Document domain models.

These are the pure data structures that move through the ingestion pipeline.
They are deliberately framework-agnostic (no FastAPI, no Qdrant types) so the
core logic depends only on these, not on any vendor SDK.
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime, timezone

from pydantic import BaseModel, Field


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _new_id() -> str:
    return uuid.uuid4().hex


class DocumentType(str, enum.Enum):
    """Coarse classification used for type-based organisation (AIC-002 ①)."""

    MANUAL = "manual"          # 업무 매뉴얼/지침
    REGULATION = "regulation"  # 제도/규칙/표준안
    FAQ = "faq"                # FAQ
    NOTICE = "notice"          # 내부 공지
    OTHER = "other"


class DocumentMetadata(BaseModel):
    """Metadata attached to a source document and propagated to every chunk."""

    business_area: str | None = Field(default=None, description="업무 영역 (수신/여신/공통 등)")
    doc_type: DocumentType = Field(default=DocumentType.OTHER)
    version: str | None = Field(default=None)
    effective_date: datetime | None = Field(default=None)
    author_dept: str | None = Field(default=None)
    is_active: bool = Field(default=True, description="최신본 여부. 폐기본은 False")


class Document(BaseModel):
    """A source document registered in the knowledge base."""

    id: str = Field(default_factory=_new_id)
    title: str
    source: str = Field(description="원본 파일명 또는 출처 식별자")
    metadata: DocumentMetadata = Field(default_factory=DocumentMetadata)
    created_at: datetime = Field(default_factory=_utcnow)
    updated_at: datetime = Field(default_factory=_utcnow)
    chunk_count: int = Field(default=0)


class Chunk(BaseModel):
    """A retrievable unit of a document (after parsing + chunking).

    ``parent_id`` enables parent-child mapping: small chunks are searched but a
    larger parent passage can be returned for richer context.
    """

    id: str = Field(default_factory=_new_id)
    document_id: str
    text: str
    parent_id: str | None = Field(default=None)
    metadata: DocumentMetadata = Field(default_factory=DocumentMetadata)
    embedding: list[float] | None = Field(default=None, repr=False)

    def to_payload(self) -> dict:
        """Flatten into a Qdrant payload (metadata stored alongside the vector)."""
        return {
            "document_id": self.document_id,
            "text": self.text,
            "parent_id": self.parent_id,
            "business_area": self.metadata.business_area,
            "doc_type": self.metadata.doc_type.value,
            "version": self.metadata.version,
            "is_active": self.metadata.is_active,
        }
