"""
파서 — 포맷별 라우팅으로 원본을 구조 보존 IR로 변환(FR-2).

상태: 인터페이스 골격. 구현은 국면 A PoC(표 복원율 게이트) 통과 후 TDD로 채운다.
behavior 테스트(P-01,04,05,06,08)가 이 클래스를 빨강으로 기다린다.

설계 결정(미정, §1.3): Python 파서의 표 복원율이 임계 미달이면
파싱만 별도 언어 서비스로 분리하고 IR(JSON)로 통신. PoC가 판정.
"""
from __future__ import annotations

from harag.schemas.ir import DocumentIR


class HwpParser:
    """HWP 5.0 / HWPX 파서. 포맷은 매직바이트로 판별(FR-1, 확장자 신뢰 안 함)."""

    def parse(self, raw: bytes, source_format: str) -> DocumentIR:
        """원본 바이트 → DocumentIR.

        구현 요구사항(tdd_test_spec.md P-01~P-08):
          - 표는 셀 좌표로 보존(평탄화 금지)
          - 조·항·호 → struct_path
          - 머리말/꼬리말 → is_noise=true
          - 다단/텍스트박스 → order_index 읽기 순서
          - 암호/손상 → parse_status=failed (예외 아님)
        """
        raise NotImplementedError("국면 A PoC 통과 후 TDD로 구현")
